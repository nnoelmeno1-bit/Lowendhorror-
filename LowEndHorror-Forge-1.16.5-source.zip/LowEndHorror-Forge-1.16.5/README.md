# LowEndHorror — Forge 1.16.5 starter

This is a **starter source project**, not a finished or tested playable JAR.

## What is included
- Forge 1.16.5 / Forge 36.2.39 Gradle setup
- Mod entry point
- Watcher monster entity class and registration

## Not included yet
- A custom model/texture for the Watcher
- Client renderer registration
- Blood Moon event
- Horror dimension and its terrain/portal
- Spawn egg and final in-game testing

## Build
Use Java 8 and Gradle/ForgeGradle. Open the project in a computer or cloud development environment and run:
`gradlew build`

The finished JAR, if the build succeeds, should be in `build/libs/`.
